# mcserverweb
我的世界基岩版服务器官网模板

通过编辑config.json即可搭建一个我的世界服务器官网

## config.json参数说明
|参数|说明|备注|
|----|----|----|
|servername|服务器名字|
|ip|服务器IP|
|port|服务器端口|
|introduced|服务器介绍|一句话介绍服务器，不建议太长
|qqgrouplink|QQ群链接|这里必须填写链接，否则不会跳转
|email|服务器邮箱|

***
## 环境要求
* PHP版本大于7.4

