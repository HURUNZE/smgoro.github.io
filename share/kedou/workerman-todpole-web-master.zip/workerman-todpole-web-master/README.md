workerman-todpole
=================

蝌蚪游泳交互程序-虚拟主机版本（静态空间、php、jsp、asp等空间都可以）。即界面html运行在你的虚拟空间上，后端通讯使用的是workerman主机。

[线上DEMO](http://kedou.workerman.net)

在自己的服务器上安装部署
==================

1、下载或者clone代码到你的虚拟主机任意目录并且能够访问kedou.html即可

2、浏览器访问地址  虚拟主机域名或者ip 如图：

![小蝌蚪游戏截图](https://github.com/walkor/workerman-todpole/blob/master/Applications/Todpole/Web/images/workerman-todpole-browser.png?raw=true)


请在界面上保留作者链接信息
==================
请在界面上保留作者链接信息,不然会被你的域名会被workerman主机屏蔽，导致无法使用。

非常感谢Rumpetroll
===================
本程序是由 [Rumpetroll](http://rumpetroll.com) 修改而来。非常感谢Rumpetroll出色的工作。  
原 [Repo: https://github.com/danielmahal/Rumpetroll](https://github.com/danielmahal/Rumpetroll)
