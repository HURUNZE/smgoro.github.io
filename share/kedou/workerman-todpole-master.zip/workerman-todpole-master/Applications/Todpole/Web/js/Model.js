var Model = function() {
	this.tadpoles = {};
	this.userTadpole;
	this.camera;
	this.settings;
}